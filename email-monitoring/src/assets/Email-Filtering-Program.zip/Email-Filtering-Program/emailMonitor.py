import imaplib
import email
import os
import schedule
import time
from email.header import decode_header

# Dane logowania do konta email
username = "Przykładowy@example.com"
password = "PrzykładoweHasło12345"
imap_server = "imap.przykładowy.com"

# Lokalny katalog na załączniki
attachment_dir = "attachments"

# Upewniamy się, że katalog na załączniki istnieje
os.makedirs(attachment_dir, exist_ok=True)

def save_attachment(msg, subject):
    # Przechodzimy przez każdą część wiadomości email
    for part in msg.walk():
        # Jeśli część jest typu multipart, pomijamy ją
        if part.get_content_maintype() == 'multipart':
            continue
        # Jeśli brak nagłówka content disposition, też ją pomijamy 
        if part.get('Content-Disposition') is None:
            continue
        # Pobieramy nazwę pliku załącznika
        filename = part.get_filename()
        if filename:
            # Zapisujemy załącznik w katalogu
            filepath = os.path.join(attachment_dir, filename)
            with open(filepath, 'wb') as f:
                f.write(part.get_payload(decode=True))
            print(f"Zapisano załącznik: {filepath}")

def process_emails():
    try:
        # Łączymy się z serwerem
        mail = imaplib.IMAP4_SSL(imap_server)
        mail.login(username, password)
        mail.select("inbox")

        # Szukamy emaili z [RED] w temacie
        status, messages = mail.search(None, '(SUBJECT "[RED]")')
        email_ids = messages[0].split()

        for email_id in email_ids:
            status, msg_data = mail.fetch(email_id, "(RFC822)")
            msg = email.message_from_bytes(msg_data[0][1])

            # Dekodujemy temat wiadomości email
            subject, encoding = decode_header(msg["Subject"])[0]
            if isinstance(subject, bytes):
                subject = subject.decode(encoding if encoding else "utf-8")

            # Sprawdzamy, czy email ma załącznik
            if msg.get_content_maintype() != 'multipart':
                continue

            # Zapisujemy temat i załącznik
            save_attachment(msg, subject)

            # Przenosimy email do folderu OLD-RED
            mail.copy(email_id, "OLD-RED")
            mail.store(email_id, '+FLAGS', '\\Deleted')

        # Usuwamy oznaczone emaile
        mail.expunge()
        mail.logout()
    except Exception as e:
        print(f"Wystąpił błąd: {e}")

# Ustawiamy przetwarzanie emaili co 10 minut
schedule.every(10).minutes.do(process_emails)

if __name__ == "__main__":
    while True:
        # Uruchomia zaplanowane zadania
        schedule.run_pending()
        # Usypia na 1 sekundę
        time.sleep(1)