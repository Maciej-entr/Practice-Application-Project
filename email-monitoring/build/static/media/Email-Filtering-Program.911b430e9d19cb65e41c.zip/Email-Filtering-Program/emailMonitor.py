import imaplib
import email
import os
import schedule
import time
from email.header import decode_header

# Email account credentials
username = "your_email@example.com"
password = "your_password"
imap_server = "imap.example.com"

# Local directory to save attachments
attachment_dir = "attachments"

# Ensure the attachment directory exists
os.makedirs(attachment_dir, exist_ok=True)

def save_attachment(msg, subject):
    for part in msg.walk():
        if part.get_content_maintype() == 'multipart':
            continue
        if part.get('Content-Disposition') is None:
            continue
        filename = part.get_filename()
        if filename:
            filepath = os.path.join(attachment_dir, filename)
            with open(filepath, 'wb') as f:
                f.write(part.get_payload(decode=True))
            print(f"Saved attachment: {filepath}")

def process_emails():
    try:
        # Connect to the server
        mail = imaplib.IMAP4_SSL(imap_server)
        mail.login(username, password)
        mail.select("inbox")

        # Search for emails with [RED] in the subject
        status, messages = mail.search(None, '(SUBJECT "[RED]")')
        email_ids = messages[0].split()

        for email_id in email_ids:
            status, msg_data = mail.fetch(email_id, "(RFC822)")
            msg = email.message_from_bytes(msg_data[0][1])

            # Decode email subject
            subject, encoding = decode_header(msg["Subject"])[0]
            if isinstance(subject, bytes):
                subject = subject.decode(encoding if encoding else "utf-8")

            # Check if the email has an attachment
            if msg.get_content_maintype() != 'multipart':
                continue

            # Save the subject and attachment
            save_attachment(msg, subject)

            # Move the email to OLD-RED folder
            mail.copy(email_id, "OLD-RED")
            mail.store(email_id, '+FLAGS', '\\Deleted')

        # Expunge deleted emails
        mail.expunge()
        mail.logout()
    except Exception as e:
        print(f"An error occurred: {e}")

# Schedule the email processing every 10 minutes
schedule.every(10).minutes.do(process_emails)

if __name__ == "__main__":
    while True:
        schedule.run_pending()
        time.sleep(1)