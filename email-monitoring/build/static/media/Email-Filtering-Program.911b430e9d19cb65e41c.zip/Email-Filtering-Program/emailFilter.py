import os.path
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.modify']

# Function to get Gmail service
def get_gmail_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    return build('gmail', 'v1', credentials=creds)

# Function to move messages to the trash
def move_to_trash_with_modify(service, user_id, msg_id):
    try:
        service.users().messages().modify(
            userId=user_id,
            id=msg_id,
            body={
                "removeLabelIds": [],
                "addLabelIds": ["TRASH"]
            }
        ).execute()
    except Exception as error:
        print(f'An error occurred: {error}')

# Function to delete emails based on criteria
def delete_emails(service, user_id, sender=None, keywords=None, whitelist=None, keyword_whitelist=None):
    try:
        query_parts = []
        
        if sender:
            query_parts.append(f'from:({sender})')
        
        if keywords:
            keyword_query = ' OR '.join(f'"{keyword}"' for keyword in keywords)
            query_parts.append(f'({keyword_query})')
        
        if not query_parts:
            raise ValueError("At least one of sender or keywords must be specified")
        
        query = ' AND '.join(query_parts)
        print(f"Executing query: {query}")
        
        # Pagination for retrieving messages
        next_page_token = None
        while True:
            results = service.users().messages().list(
                userId=user_id, q=query, pageToken=next_page_token, format='metadata', metadataHeaders=['From']
            ).execute()
            messages = results.get('messages', [])
            next_page_token = results.get('nextPageToken')

            if not messages:
                print('No more messages found.')
                break

            for message in messages:
                msg_id = message['id']
                headers = message['payload']['headers']
                msg_sender = next((header['value'] for header in headers if header['name'] == 'From'), None)

                # Check if the sender is in the whitelist
                if whitelist and any(whitelisted in msg_sender for whitelisted in whitelist):
                    print(f'Message from {msg_sender} is whitelisted and will not be trashed.')
                    continue

                # Get the message snippet to check for keyword whitelist (like "RED")
                msg = service.users().messages().get(userId=user_id, id=msg_id, format='full').execute()
                snippet = msg.get('snippet', '').lower()

                # Check if the message contains whitelisted keywords
                if keyword_whitelist and any(whitelisted_keyword.lower() in snippet for whitelisted_keyword in keyword_whitelist):
                    print(f'Message with whitelisted keyword found in snippet, skipping deletion: {snippet}')
                    continue

                # Move to trash
                move_to_trash_with_modify(service, user_id, msg_id)
                print(f'Message ID: {msg_id} from {msg_sender} moved to trash.')

            if not next_page_token:
                break

    except Exception as error:
        print(f'An error occurred: {error}')

# GUI function for deletion process
def on_delete():
    sender = sender_entry.get()
    keywords = keyword_entry.get().split(",")  # Split keywords by comma
    whitelist = whitelist_entry.get().split(",")  # Split whitelist by comma
    keyword_whitelist = ['RED']  # Hardcoding "RED" in the whitelist
    
    if not sender and not keywords:
        messagebox.showwarning("Input Error", "Please provide a sender or keywords.")
        return
    
    try:
        service = get_gmail_service()  # Call your existing Gmail service setup
        delete_emails(service, 'me', sender=sender, keywords=keywords, whitelist=whitelist, keyword_whitelist=keyword_whitelist)
        messagebox.showinfo("Success", "Emails processed successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

# Create the root window
root = tk.Tk()
root.title("Gmail Email Deleter")
root.geometry("400x300")

# Use ttk for modern themed widgets
style = ttk.Style()
style.configure("TLabel", padding=6)
style.configure("TEntry", padding=6)
style.configure("TButton", padding=6)

# Labels and Entry fields
ttk.Label(root, text="Sender Email:").pack(pady=5)
sender_entry = ttk.Entry(root, width=40)
sender_entry.pack(pady=5)

ttk.Label(root, text="Keywords (comma separated):").pack(pady=5)
keyword_entry = ttk.Entry(root, width=40)
keyword_entry.pack(pady=5)

ttk.Label(root, text="Whitelist (comma separated):").pack(pady=5)
whitelist_entry = ttk.Entry(root, width=40)
whitelist_entry.pack(pady=5)

# Button to trigger the delete process
delete_button = ttk.Button(root, text="Delete Emails", command=on_delete)
delete_button.pack(pady=20)

# Start the Tkinter loop
root.mainloop()